# BigLobby3
BigLobby: No PDMod Required!

# Credits:
- Polarathene: Original version of the mod located here: https://github.com/polarathene/biglobby
- steam-test1: Contributor to current/previous project
- ZNix: SuperBLT creator, XML injection API used to obsolete the pdmod file
- RESTORATION Mod team: Additional R&D
